import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axiosClient from '../api/axiosClient';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { trackClickCTA } from '../utils/analytics';
import Breadcrumbs from '../components/Breadcrumbs';
import {
  Package,
  Tags,
  DollarSign,
  AlertTriangle,
  ArrowRight,
  PlusCircle,
  Download,
  CheckCircle,
  TrendingUp,
  RefreshCw,
  Boxes,
  ShieldCheck,
} from 'lucide-react';

const Dashboard = () => {
  const { user } = useAuth();
  const toast = useToast();

  const [items, setItems] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchData = async (isRefresh = false) => {
    if (isRefresh) setRefreshing(true);
    else setLoading(true);

    try {
      const [itemsRes, catRes] = await Promise.all([
        axiosClient.get('/items'),
        axiosClient.get('/categories'),
      ]);

      setItems(itemsRes.data.data || []);
      setCategories(catRes.data.data || []);

      if (isRefresh) {
        toast.success('Data dashboard berhasil diperbarui dari server API.', 'Data Terkini');
      }
    } catch (error) {
      console.error('Error loading dashboard data:', error);
      toast.error('Gagal mengambil data inventaris dari API backend.', 'Koneksi Gagal');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Compute metrics
  const totalItems = items.length;
  const totalCategories = categories.length;
  const totalValuation = items.reduce((acc, item) => acc + (Number(item.stock) * Number(item.price)), 0);
  const lowStockItems = items.filter((item) => Number(item.stock) < 10);

  // Format currency
  const formatIDR = (val) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      maximumFractionDigits: 0,
    }).format(val || 0);
  };

  // Export backup snapshot
  const handleBackupExport = () => {
    trackClickCTA('dashboard_backup_export');
    const backupData = {
      exportedAt: new Date().toISOString(),
      exporter: user?.email,
      categoriesCount: categories.length,
      itemsCount: items.length,
      totalValuation,
      categories,
      items,
    };

    const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `backup_inventaris_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    toast.success('Data cadangan inventaris berhasil di-export sebagai file JSON!', 'Backup Selesai');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Breadcrumb Navigation */}
      <Breadcrumbs />

      {/* Hero Welcome Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-indigo-700 via-indigo-600 to-violet-700 text-white p-8 sm:p-10 shadow-xl shadow-indigo-200">
        <div className="absolute -right-10 -bottom-10 w-64 h-64 bg-white/10 rounded-full blur-2xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center md:justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/15 backdrop-blur-md text-xs font-semibold text-indigo-100">
              <ShieldCheck size={14} />
              <span>Sanctum Authenticated Session</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Selamat Datang, {user?.name || 'Administrator'}!
            </h1>
            <p className="text-xs sm:text-sm text-indigo-100 max-w-2xl leading-relaxed">
              Pantau arus pergerakan stok barang, nilai aset gudang, dan kelola klasifikasi kategori inventaris Anda dengan mudah dan akurat secara real-time.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => fetchData(true)}
              disabled={refreshing}
              id="btn-refresh-dashboard"
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white/20 hover:bg-white/30 text-white text-xs font-semibold backdrop-blur-md transition disabled:opacity-50"
            >
              <RefreshCw size={15} className={refreshing ? 'animate-spin' : ''} />
              <span>Refresh Data</span>
            </button>

            <button
              type="button"
              onClick={handleBackupExport}
              id="btn-export-backup"
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-semibold shadow-md transition"
            >
              <Download size={15} />
              <span>Backup JSON</span>
            </button>
          </div>
        </div>
      </div>

      {/* Metric Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {/* Card 1: Total Items */}
        <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Total Barang</span>
            <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <Package size={20} />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-2xl font-extrabold text-slate-900">
              {loading ? '...' : totalItems}
            </div>
            <div className="text-xs text-slate-400 mt-1 flex items-center gap-1">
              <span>Barang aktif di sistem</span>
            </div>
          </div>
        </div>

        {/* Card 2: Total Categories */}
        <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Total Kategori</span>
            <div className="w-10 h-10 rounded-xl bg-violet-50 text-violet-600 flex items-center justify-center">
              <Tags size={20} />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-2xl font-extrabold text-slate-900">
              {loading ? '...' : totalCategories}
            </div>
            <div className="text-xs text-slate-400 mt-1 flex items-center gap-1">
              <span>Klasifikasi produk</span>
            </div>
          </div>
        </div>

        {/* Card 3: Total Valuation */}
        <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Nilai Inventaris</span>
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <TrendingUp size={20} />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-lg sm:text-xl font-extrabold text-slate-900 truncate">
              {loading ? '...' : formatIDR(totalValuation)}
            </div>
            <div className="text-xs text-slate-400 mt-1 flex items-center gap-1">
              <span>Akumulasi stok × harga</span>
            </div>
          </div>
        </div>

        {/* Card 4: Low Stock Alert */}
        <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Stok Kritis (&lt;10)</span>
            <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
              <AlertTriangle size={20} />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-2xl font-extrabold text-amber-600">
              {loading ? '...' : lowStockItems.length}
            </div>
            <div className="text-xs text-slate-400 mt-1 flex items-center gap-1">
              <span>Perlu pengadaan ulang</span>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Action Navigation Buttons */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <Link
          to="/items"
          onClick={() => trackClickCTA('dashboard_goto_items')}
          className="group p-6 rounded-2xl bg-white border border-slate-100 shadow-sm hover:shadow-md hover:border-indigo-200 transition flex items-center justify-between"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center group-hover:scale-105 transition-transform">
              <Package size={24} />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900 group-hover:text-indigo-600 transition">
                Kelola Data Barang (Items)
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Tambah barang baru, perbarui SKU, pantau jumlah stok, dan filter per kategori.
              </p>
            </div>
          </div>
          <ArrowRight size={18} className="text-slate-400 group-hover:text-indigo-600 group-hover:translate-x-1 transition-all" />
        </Link>

        <Link
          to="/categories"
          onClick={() => trackClickCTA('dashboard_goto_categories')}
          className="group p-6 rounded-2xl bg-white border border-slate-100 shadow-sm hover:shadow-md hover:border-violet-200 transition flex items-center justify-between"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-violet-50 text-violet-600 flex items-center justify-center group-hover:scale-105 transition-transform">
              <Tags size={24} />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900 group-hover:text-violet-600 transition">
                Kelola Kategori Barang
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Susun kelompok kategori produk untuk mempermudah inventarisasi dan pelaporan.
              </p>
            </div>
          </div>
          <ArrowRight size={18} className="text-slate-400 group-hover:text-violet-600 group-hover:translate-x-1 transition-all" />
        </Link>
      </div>

      {/* Recent Items Table Preview */}
      <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Daftar Barang Terbaru</h3>
            <p className="text-xs text-slate-400 mt-0.5">Snapshot produk terkini yang tersimpan di sistem inventaris</p>
          </div>
          <Link
            to="/items"
            className="text-xs font-semibold text-indigo-600 hover:text-indigo-700 flex items-center gap-1"
          >
            <span>Lihat Semua ({totalItems})</span>
            <ArrowRight size={14} />
          </Link>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider font-semibold border-b border-slate-100">
              <tr>
                <th className="py-3.5 px-6">Nama Barang</th>
                <th className="py-3.5 px-6">SKU</th>
                <th className="py-3.5 px-6">Kategori</th>
                <th className="py-3.5 px-6">Stok</th>
                <th className="py-3.5 px-6">Harga Satuan</th>
                <th className="py-3.5 px-6">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {loading ? (
                <tr>
                  <td colSpan={6} className="text-center py-8 text-slate-400">
                    Memuat data barang...
                  </td>
                </tr>
              ) : items.length === 0 ? (
                <tr>
                  <td colSpan={6} className="text-center py-8 text-slate-400">
                    Belum ada barang di inventaris. Silakan tambah barang baru.
                  </td>
                </tr>
              ) : (
                items.slice(0, 5).map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50/80 transition">
                    <td className="py-3.5 px-6 font-semibold text-slate-900">{item.name}</td>
                    <td className="py-3.5 px-6 font-mono text-slate-500">{item.sku}</td>
                    <td className="py-3.5 px-6">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-slate-100 text-slate-700">
                        {item.category?.name || '-'}
                      </span>
                    </td>
                    <td className="py-3.5 px-6 font-semibold">{item.stock} unit</td>
                    <td className="py-3.5 px-6">{formatIDR(item.price)}</td>
                    <td className="py-3.5 px-6">
                      {Number(item.stock) <= 5 ? (
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold bg-rose-100 text-rose-700">
                          Kritis (&le;5)
                        </span>
                      ) : Number(item.stock) < 10 ? (
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-100 text-amber-700">
                          Menipis (&lt;10)
                        </span>
                      ) : (
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-100 text-emerald-700">
                          Tersedia
                        </span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
