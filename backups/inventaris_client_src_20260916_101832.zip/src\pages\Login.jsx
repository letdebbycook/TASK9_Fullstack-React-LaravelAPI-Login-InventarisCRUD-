import React, { useState } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { trackClickCTA, trackFormSubmit } from '../utils/analytics';
import {
  Boxes,
  Lock,
  Mail,
  User,
  ArrowRight,
  ShieldCheck,
  AlertCircle,
  KeyRound,
  CheckCircle2,
  Sparkles,
} from 'lucide-react';

const Login = () => {
  const [mode, setMode] = useState('login'); // 'login' | 'register'
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Form states
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [passwordConfirmation, setPasswordConfirmation] = useState('');

  // Anti-spam honeypot field (hidden from genuine users)
  const [honeypot, setHoneypot] = useState('');

  const { login, register, isAuthenticated } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const location = useLocation();

  const redirectPath = location.state?.from?.pathname || '/';

  // If already authenticated, redirect to dashboard
  React.useEffect(() => {
    if (isAuthenticated) {
      navigate(redirectPath, { replace: true });
    }
  }, [isAuthenticated, navigate, redirectPath]);

  // Quick fill test credentials
  const fillDemoAccount = () => {
    setMode('login');
    setEmail('test@example.com');
    setPassword('password');
    setErrorMsg('');
    toast.info('Kredensial akun pengujian telah diisi otomatis!', 'Akun Demo');
    trackClickCTA('autofill_demo_account');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrorMsg('');

    // 1. Anti-spam honeypot validation
    if (honeypot.trim() !== '') {
      console.warn('Spam submission intercepted via honeypot field');
      toast.error('Spam bot detected! Pengiriman formulir dibatalkan.', 'Anti-Spam Terdeteksi');
      trackFormSubmit(mode === 'login' ? 'login_form' : 'register_form', 'spam_rejected');
      return;
    }

    // 2. Client-side validation
    if (!email || !email.includes('@')) {
      const msg = 'Format email tidak valid. Harap gunakan format yang benar (contoh@domain.com).';
      setErrorMsg(msg);
      toast.warning(msg, 'Validasi Gagal');
      return;
    }

    if (password.length < 6) {
      const msg = 'Password minimal harus 6 karakter (disarankan 8 karakter untuk registrasi).';
      setErrorMsg(msg);
      toast.warning(msg, 'Validasi Gagal');
      return;
    }

    if (mode === 'register') {
      if (!name.trim()) {
        const msg = 'Nama lengkap wajib diisi.';
        setErrorMsg(msg);
        toast.warning(msg, 'Validasi Gagal');
        return;
      }
      if (password.length < 8) {
        const msg = 'Password minimal 8 karakter untuk keamanan pendaftaran.';
        setErrorMsg(msg);
        toast.warning(msg, 'Validasi Gagal');
        return;
      }
      if (password !== passwordConfirmation) {
        const msg = 'Konfirmasi password tidak cocok dengan password yang dimasukkan.';
        setErrorMsg(msg);
        toast.warning(msg, 'Validasi Gagal');
        return;
      }
    }

    setLoading(true);

    if (mode === 'login') {
      const result = await login(email, password);
      setLoading(false);

      if (result.success) {
        navigate(redirectPath, { replace: true });
      } else {
        setErrorMsg(result.message);
      }
    } else {
      // Register
      const result = await register(name, email, password, passwordConfirmation);
      setLoading(false);

      if (result.success) {
        navigate(redirectPath, { replace: true });
      } else {
        // Specifically catch duplicate email message
        setErrorMsg(result.message);
      }
    }
  };

  return (
    <div className="min-h-[85vh] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 bg-slate-50">
      <div className="max-w-md w-full space-y-8 bg-white p-8 sm:p-10 rounded-3xl shadow-xl shadow-slate-200/60 border border-slate-100 relative overflow-hidden">
        {/* Background glow element */}
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-violet-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Header Branding */}
        <div className="text-center relative">
          <div className="inline-flex p-3 rounded-2xl bg-gradient-to-tr from-indigo-600 to-violet-600 text-white shadow-lg shadow-indigo-200 mb-3">
            <Boxes size={28} />
          </div>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">
            {mode === 'login' ? 'Masuk ke InventarisPro' : 'Buat Akun Pengelola'}
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            {mode === 'login'
              ? 'Kelola data inventaris dan kategori secara realtime'
              : 'Daftarkan akun baru untuk akses API Sanctum terproteksi'}
          </p>
        </div>

        {/* Mode Switch Tabs */}
        <div className="flex p-1 bg-slate-100 rounded-xl">
          <button
            type="button"
            className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-all ${
              mode === 'login'
                ? 'bg-white text-indigo-700 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
            onClick={() => {
              setMode('login');
              setErrorMsg('');
              trackClickCTA('tab_switch_login');
            }}
          >
            Masuk (Login)
          </button>
          <button
            type="button"
            className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-all ${
              mode === 'register'
                ? 'bg-white text-indigo-700 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
            onClick={() => {
              setMode('register');
              setErrorMsg('');
              trackClickCTA('tab_switch_register');
            }}
          >
            Daftar Baru
          </button>
        </div>

        {/* Inline Error / Alert message if any */}
        {errorMsg && (
          <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-start gap-2.5 animate-shake">
            <AlertCircle size={16} className="shrink-0 mt-0.5" />
            <div className="flex-1 font-medium">{errorMsg}</div>
          </div>
        )}

        {/* The Form */}
        <form onSubmit={handleSubmit} className="space-y-4" noValidate>
          {/* Anti-Spam Honeypot Field (Visually Hidden) */}
          <div style={{ display: 'none', position: 'absolute', left: '-9999px' }} aria-hidden="true">
            <label htmlFor="_hp_check">Leave this field blank</label>
            <input
              type="text"
              id="_hp_check"
              name="_hp_check"
              value={honeypot}
              onChange={(e) => setHoneypot(e.target.value)}
              tabIndex={-1}
              autoComplete="off"
            />
          </div>

          {mode === 'register' && (
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5" htmlFor="reg-name">
                Nama Lengkap
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                  <User size={16} />
                </div>
                <input
                  id="reg-name"
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Misal: John Doe"
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5" htmlFor="auth-email">
              Alamat Email
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                <Mail size={16} />
              </div>
              <input
                id="auth-email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="nama@perusahaan.com"
                className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5" htmlFor="auth-password">
              Kata Sandi (Password)
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                <Lock size={16} />
              </div>
              <input
                id="auth-password"
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition"
              />
            </div>
          </div>

          {mode === 'register' && (
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5" htmlFor="auth-password-confirm">
                Konfirmasi Kata Sandi
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                  <KeyRound size={16} />
                </div>
                <input
                  id="auth-password-confirm"
                  type="password"
                  required
                  value={passwordConfirmation}
                  onChange={(e) => setPasswordConfirmation(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition"
                />
              </div>
            </div>
          )}

          {/* Submit CTA */}
          <button
            type="submit"
            disabled={loading}
            id="btn-auth-submit"
            className="w-full py-3 px-4 rounded-xl text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 focus:ring-4 focus:ring-indigo-200 transition-all flex items-center justify-center gap-2 shadow-lg shadow-indigo-200 disabled:opacity-70 disabled:cursor-not-allowed cursor-pointer"
          >
            {loading ? (
              <span className="inline-flex items-center gap-2">
                <span className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
                <span>Memproses Data...</span>
              </span>
            ) : (
              <>
                <span>{mode === 'login' ? 'Masuk Sekarang' : 'Daftarkan Akun'}</span>
                <ArrowRight size={15} />
              </>
            )}
          </button>
        </form>

        {/* Demo Account Helper Quickfill */}
        <div className="pt-4 border-t border-slate-100">
          <div className="p-3 rounded-2xl bg-indigo-50/70 border border-indigo-100 flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-indigo-900 flex items-center gap-1.5">
                <Sparkles size={13} className="text-indigo-600" />
                Akun Demo Backend (Task 8)
              </span>
              <button
                type="button"
                onClick={fillDemoAccount}
                className="text-[10px] font-bold text-indigo-700 bg-white px-2.5 py-1 rounded-lg border border-indigo-200 hover:bg-indigo-100 transition shadow-xs"
              >
                Gunakan Akun Demo
              </button>
            </div>
            <p className="text-[10px] text-indigo-700/80">
              Email: <code className="font-mono bg-white/80 px-1 rounded">test@example.com</code> | Password: <code className="font-mono bg-white/80 px-1 rounded">password</code>
            </p>
          </div>
        </div>

        {/* Security badge */}
        <div className="flex items-center justify-center gap-2 text-[11px] text-slate-400">
          <ShieldCheck size={14} className="text-emerald-500" />
          <span>Protected with Laravel Sanctum API Token</span>
        </div>
      </div>
    </div>
  );
};

export default Login;
