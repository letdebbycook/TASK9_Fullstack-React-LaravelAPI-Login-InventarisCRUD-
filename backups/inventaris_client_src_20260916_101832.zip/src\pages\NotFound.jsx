import React, { useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { trackEvent, trackClickCTA } from '../utils/analytics';
import { HelpCircle, Home, Package, ArrowLeft, Search } from 'lucide-react';

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    trackEvent('page_not_found_404', {
      attemptedPath: location.pathname,
      referrer: document.referrer,
    });
  }, [location.pathname]);

  return (
    <div className="min-h-[75vh] flex items-center justify-center px-4 py-12">
      <div className="max-w-md w-full text-center space-y-6 bg-white p-8 sm:p-10 rounded-3xl border border-slate-100 shadow-xl">
        <div className="relative inline-block">
          <div className="text-8xl font-black text-indigo-100 tracking-wider">404</div>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-16 h-16 rounded-2xl bg-indigo-600 text-white flex items-center justify-center shadow-lg shadow-indigo-300">
              <HelpCircle size={32} />
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <h1 className="text-xl font-extrabold text-slate-900">Halaman Tidak Ditemukan</h1>
          <p className="text-xs text-slate-500 leading-relaxed">
            Maaf, tautan atau alamat <code className="bg-slate-100 px-1.5 py-0.5 rounded text-indigo-600 font-mono text-[11px]">{location.pathname}</code> tidak tersedia atau telah dipindahkan.
          </p>
        </div>

        <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
          <Link
            to="/"
            onClick={() => trackClickCTA('404_back_to_home')}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-md shadow-indigo-200 transition"
          >
            <Home size={15} />
            <span>Kembali ke Dashboard</span>
          </Link>
          <Link
            to="/items"
            onClick={() => trackClickCTA('404_view_items')}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold transition"
          >
            <Package size={15} />
            <span>Lihat Data Barang</span>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default NotFound;
