import React, { useState, useEffect } from 'react';
import axiosClient from '../api/axiosClient';
import { useToast } from '../context/ToastContext';
import { trackFormSubmit, trackClickCTA } from '../utils/analytics';
import Breadcrumbs from '../components/Breadcrumbs';
import {
  Tags,
  Plus,
  Edit2,
  Trash2,
  Search,
  AlertTriangle,
  X,
  Package,
  CheckCircle2,
  RefreshCw,
  FolderOpen,
} from 'lucide-react';

const Categories = () => {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState('create'); // 'create' | 'edit'
  const [currentCategory, setCurrentCategory] = useState(null);
  const [categoryName, setCategoryName] = useState('');
  const [formLoading, setFormLoading] = useState(false);
  const [formError, setFormError] = useState('');

  // Anti-spam honeypot field
  const [honeypot, setHoneypot] = useState('');

  // Delete Confirmation Modal
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [categoryToDelete, setCategoryToDelete] = useState(null);
  const [deleteLoading, setDeleteLoading] = useState(false);

  const toast = useToast();

  const fetchCategories = async (notify = false) => {
    try {
      if (!notify) setLoading(true);
      const res = await axiosClient.get('/categories');
      setCategories(res.data.data || []);
      if (notify) {
        toast.success('Daftar kategori berhasil diperbarui!', 'Kategori Sinkron');
      }
    } catch (error) {
      console.error('Error fetching categories:', error);
      toast.error('Gagal mengambil daftar kategori dari API backend.', 'Error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCategories();
  }, []);

  // Filter categories by search
  const filteredCategories = categories.filter((cat) =>
    cat.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Open Create Modal
  const handleOpenCreate = () => {
    setModalMode('create');
    setCurrentCategory(null);
    setCategoryName('');
    setFormError('');
    setHoneypot('');
    setIsModalOpen(true);
    trackClickCTA('open_create_category_modal');
  };

  // Open Edit Modal
  const handleOpenEdit = (cat) => {
    setModalMode('edit');
    setCurrentCategory(cat);
    setCategoryName(cat.name);
    setFormError('');
    setHoneypot('');
    setIsModalOpen(true);
    trackClickCTA('open_edit_category_modal');
  };

  // Handle Form Submit (Create / Update)
  const handleSubmitCategory = async (e) => {
    e.preventDefault();
    setFormError('');

    // Honeypot check
    if (honeypot.trim() !== '') {
      toast.error('Spam terdeteksi! Formulir ditolak.', 'Anti-Spam');
      trackFormSubmit('category_form', 'spam_rejected');
      return;
    }

    if (!categoryName.trim()) {
      const msg = 'Nama kategori wajib diisi.';
      setFormError(msg);
      toast.warning(msg, 'Validasi');
      return;
    }

    setFormLoading(true);

    try {
      if (modalMode === 'create') {
        const res = await axiosClient.post('/categories', { name: categoryName.trim() });
        const newCat = res.data.data;
        setCategories((prev) => [...prev, newCat]);
        setIsModalOpen(false);
        trackFormSubmit('category_create', 'success', { name: newCat.name });
        toast.success(`Kategori "${newCat.name}" berhasil dibuat!`, 'Berhasil');
      } else {
        const res = await axiosClient.put(`/categories/${currentCategory.id}`, { name: categoryName.trim() });
        const updated = res.data.data;
        setCategories((prev) =>
          prev.map((c) => (c.id === updated.id ? { ...c, name: updated.name } : c))
        );
        setIsModalOpen(false);
        trackFormSubmit('category_update', 'success', { id: currentCategory.id, name: updated.name });
        toast.success(`Kategori "${updated.name}" berhasil diperbarui!`, 'Berhasil');
      }
    } catch (error) {
      console.error('Category form error:', error);
      let msg = 'Terjadi kesalahan saat menyimpan kategori.';
      if (error.response?.data?.errors?.name) {
        msg = error.response.data.errors.name[0];
      } else if (error.response?.data?.message) {
        msg = error.response.data.message;
      }
      setFormError(msg);
      toast.error(msg, 'Gagal Menyimpan');
      trackFormSubmit('category_form', 'error', { error: msg });
    } finally {
      setFormLoading(false);
    }
  };

  // Open Delete Confirmation Modal
  const handleOpenDelete = (cat) => {
    setCategoryToDelete(cat);
    setDeleteModalOpen(true);
    trackClickCTA('open_delete_category_modal');
  };

  // Confirm Delete
  const handleConfirmDelete = async () => {
    if (!categoryToDelete) return;
    setDeleteLoading(true);

    try {
      const catName = categoryToDelete.name;
      const res = await axiosClient.delete(`/categories/${categoryToDelete.id}`);
      setCategories((prev) => prev.filter((c) => c.id !== categoryToDelete.id));
      setDeleteModalOpen(false);
      setCategoryToDelete(null);

      const serverMsg = res.data?.message || `Kategori "${catName}" berhasil dihapus.`;
      toast.success(serverMsg, 'Kategori Dihapus');
      trackFormSubmit('category_delete', 'success', { name: catName });
    } catch (error) {
      console.error('Delete category error:', error);
      const msg = error.response?.data?.message || 'Gagal menghapus kategori.';
      toast.error(msg, 'Gagal Hapus');
      trackFormSubmit('category_delete', 'error', { error: msg });
    } finally {
      setDeleteLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Breadcrumb Navigation */}
      <Breadcrumbs />

      {/* Header & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-violet-50 text-violet-600">
              <Tags size={20} />
            </div>
            <h1 className="text-xl font-extrabold text-slate-900 tracking-tight">
              Manajemen Kategori
            </h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Kelola pengelompokan barang inventaris untuk kemudahan filter dan klasifikasi gudang.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => fetchCategories(true)}
            className="p-2.5 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 transition"
            title="Refresh data kategori"
          >
            <RefreshCw size={16} />
          </button>
          <button
            type="button"
            onClick={handleOpenCreate}
            id="btn-add-category"
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-md shadow-indigo-200 transition cursor-pointer"
          >
            <Plus size={16} />
            <span>Tambah Kategori</span>
          </button>
        </div>
      </div>

      {/* Search Bar */}
      <div className="flex items-center gap-3 bg-white p-4 rounded-2xl border border-slate-100 shadow-sm">
        <div className="relative flex-1">
          <Search size={16} className="absolute inset-y-0 left-3 my-auto text-slate-400" />
          <input
            type="text"
            placeholder="Cari kategori berdasarkan nama..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>
        <span className="text-xs text-slate-400 font-medium">
          Total: {filteredCategories.length} Kategori
        </span>
      </div>

      {/* Categories Table */}
      <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider font-semibold border-b border-slate-100">
              <tr>
                <th className="py-4 px-6 w-16">ID</th>
                <th className="py-4 px-6">Nama Kategori</th>
                <th className="py-4 px-6 text-center">Jumlah Barang Terkait</th>
                <th className="py-4 px-6 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {loading ? (
                <tr>
                  <td colSpan={4} className="text-center py-10 text-slate-400">
                    Memuat daftar kategori...
                  </td>
                </tr>
              ) : filteredCategories.length === 0 ? (
                <tr>
                  <td colSpan={4} className="text-center py-12 text-slate-400">
                    <FolderOpen size={36} className="mx-auto text-slate-300 mb-2" />
                    <p className="font-medium text-slate-600">Tidak ada kategori ditemukan</p>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      {searchQuery ? 'Coba ubah kata kunci pencarian.' : 'Klik "Tambah Kategori" untuk membuat kategori baru.'}
                    </p>
                  </td>
                </tr>
              ) : (
                filteredCategories.map((cat) => (
                  <tr key={cat.id} className="hover:bg-slate-50/80 transition">
                    <td className="py-4 px-6 font-mono text-slate-400 font-medium">#{cat.id}</td>
                    <td className="py-4 px-6">
                      <div className="font-bold text-slate-900">{cat.name}</div>
                    </td>
                    <td className="py-4 px-6 text-center">
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-violet-50 text-violet-700 border border-violet-100">
                        <Package size={13} />
                        <span>{cat.items_count ?? cat.items?.length ?? 0} barang</span>
                      </span>
                    </td>
                    <td className="py-4 px-6 text-right">
                      <div className="inline-flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => handleOpenEdit(cat)}
                          className="p-1.5 text-indigo-600 hover:bg-indigo-50 rounded-lg transition"
                          title="Edit kategori"
                        >
                          <Edit2 size={15} />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleOpenDelete(cat)}
                          className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg transition"
                          title="Hapus kategori"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create / Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-100 relative">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-violet-50 text-violet-600">
                  <Tags size={18} />
                </div>
                <h3 className="text-sm font-bold text-slate-900">
                  {modalMode === 'create' ? 'Tambah Kategori Baru' : 'Edit Data Kategori'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X size={18} />
              </button>
            </div>

            {formError && (
              <div className="mt-4 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
                <AlertTriangle size={15} className="shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleSubmitCategory} className="mt-4 space-y-4">
              {/* Anti-spam honeypot */}
              <div style={{ display: 'none' }} aria-hidden="true">
                <input
                  type="text"
                  name="_hp_cat"
                  value={honeypot}
                  onChange={(e) => setHoneypot(e.target.value)}
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5" htmlFor="cat-name">
                  Nama Kategori <span className="text-rose-500">*</span>
                </label>
                <input
                  id="cat-name"
                  type="text"
                  required
                  placeholder="Misal: Perangkat Keras / Alat Tulis"
                  value={categoryName}
                  onChange={(e) => setCategoryName(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={formLoading}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 shadow-md shadow-indigo-200 transition disabled:opacity-50"
                >
                  {formLoading ? 'Menyimpan...' : modalMode === 'create' ? 'Tambah Kategori' : 'Simpan Perubahan'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-fade-in">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl border border-slate-100 text-center">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto mb-3">
              <AlertTriangle size={24} />
            </div>
            <h3 className="text-sm font-bold text-slate-900">Konfirmasi Hapus Kategori</h3>
            <p className="text-xs text-slate-500 mt-2 leading-relaxed">
              Apakah Anda yakin ingin menghapus kategori <strong className="text-slate-800">"{categoryToDelete?.name}"</strong>?
            </p>
            <p className="text-[11px] text-amber-600 bg-amber-50 p-2.5 rounded-xl border border-amber-200 mt-3 text-left">
              <strong>Peringatan Cascade:</strong> Menghapus kategori ini juga akan menghapus barang yang terhubung di dalamnya!
            </p>

            <div className="flex items-center justify-center gap-2 mt-5">
              <button
                type="button"
                onClick={() => setDeleteModalOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition"
              >
                Batal
              </button>
              <button
                type="button"
                disabled={deleteLoading}
                onClick={handleConfirmDelete}
                className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 shadow-md shadow-rose-200 transition disabled:opacity-50"
              >
                {deleteLoading ? 'Menghapus...' : 'Ya, Hapus Kategori'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Categories;
