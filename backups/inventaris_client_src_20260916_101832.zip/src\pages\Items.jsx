import React, { useState, useEffect } from 'react';
import axiosClient from '../api/axiosClient';
import { useToast } from '../context/ToastContext';
import { trackFormSubmit, trackClickCTA } from '../utils/analytics';
import Breadcrumbs from '../components/Breadcrumbs';
import {
  Package,
  Plus,
  Edit2,
  Trash2,
  Search,
  Filter,
  Download,
  AlertTriangle,
  X,
  Sparkles,
  RefreshCw,
  FolderOpen,
  ArrowUpDown,
} from 'lucide-react';

const Items = () => {
  const [items, setItems] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);

  // Filters & Search
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [sortBy, setSortBy] = useState('name_asc');

  // Modal State (Create / Edit)
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState('create'); // 'create' | 'edit'
  const [currentItem, setCurrentItem] = useState(null);

  // Form Fields
  const [categoryId, setCategoryId] = useState('');
  const [name, setName] = useState('');
  const [sku, setSku] = useState('');
  const [stock, setStock] = useState('');
  const [price, setPrice] = useState('');
  const [formLoading, setFormLoading] = useState(false);
  const [formErrors, setFormErrors] = useState({});

  // Anti-spam honeypot
  const [honeypot, setHoneypot] = useState('');

  // Delete Modal
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [itemToDelete, setItemToDelete] = useState(null);
  const [deleteLoading, setDeleteLoading] = useState(false);

  const toast = useToast();

  // Load initial items & categories
  const fetchData = async (notify = false) => {
    try {
      if (!notify) setLoading(true);
      const [itemsRes, catRes] = await Promise.all([
        axiosClient.get(selectedCategory ? `/items?category_id=${selectedCategory}` : '/items'),
        axiosClient.get('/categories'),
      ]);

      setItems(itemsRes.data.data || []);
      setCategories(catRes.data.data || []);

      if (notify) {
        toast.success('Daftar barang dan kategori berhasil disinkronkan.', 'Data Diperbarui');
      }
    } catch (error) {
      console.error('Error loading items data:', error);
      toast.error('Gagal mengambil data dari server API.', 'Error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [selectedCategory]);

  // Handle category filter change with notification
  const handleCategoryChange = (e) => {
    const val = e.target.value;
    setSelectedCategory(val);
    trackClickCTA('filter_item_category', val);

    if (val) {
      const cat = categories.find((c) => String(c.id) === String(val));
      toast.info(`Menampilkan barang untuk kategori: "${cat?.name || 'Terpilih'}"`, 'Filter Kategori');
    } else {
      toast.info('Menampilkan semua kategori barang.', 'Filter Direset');
    }
  };

  // Format currency
  const formatIDR = (val) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      maximumFractionDigits: 0,
    }).format(val || 0);
  };

  // Auto-generate SKU helper
  const generateSkuHelper = () => {
    const prefix = selectedCategory
      ? categories.find((c) => String(c.id) === String(categoryId))?.name.substring(0, 3).toUpperCase() || 'ITM'
      : 'ITM';
    const rand = Math.floor(100 + Math.random() * 900);
    const newSku = `${prefix}-${rand}`;
    setSku(newSku);
    toast.info(`SKU otomatis dibuat: ${newSku}`, 'SKU Generator');
  };

  // Open Create Modal
  const handleOpenCreate = () => {
    setModalMode('create');
    setCurrentItem(null);
    setCategoryId(categories[0]?.id || '');
    setName('');
    setSku('');
    setStock('');
    setPrice('');
    setFormErrors({});
    setHoneypot('');
    setIsModalOpen(true);
    trackClickCTA('open_create_item_modal');
  };

  // Open Edit Modal
  const handleOpenEdit = (item) => {
    setModalMode('edit');
    setCurrentItem(item);
    setCategoryId(item.category_id || item.category?.id || '');
    setName(item.name);
    setSku(item.sku);
    setStock(item.stock);
    setPrice(item.price);
    setFormErrors({});
    setHoneypot('');
    setIsModalOpen(true);
    trackClickCTA('open_edit_item_modal');
  };

  // Submit Item Form
  const handleSubmitItem = async (e) => {
    e.preventDefault();
    setFormErrors({});

    // Honeypot check
    if (honeypot.trim() !== '') {
      toast.error('Spam bot detected! Pengiriman barang dibatalkan.', 'Anti-Spam');
      trackFormSubmit('item_form', 'spam_rejected');
      return;
    }

    // Client validation
    const errors = {};
    if (!categoryId) errors.category_id = ['Kategori wajib dipilih.'];
    if (!name.trim()) errors.name = ['Nama barang wajib diisi.'];
    if (!sku.trim()) errors.sku = ['SKU wajib diisi.'];
    if (stock === '' || isNaN(stock) || Number(stock) < 0) errors.stock = ['Stok harus berupa angka minimal 0.'];
    if (price === '' || isNaN(price) || Number(price) < 0) errors.price = ['Harga harus berupa angka minimal 0.'];

    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      toast.warning('Silakan periksa kembali isian formulir barang.', 'Validasi Form');
      return;
    }

    setFormLoading(true);

    const payload = {
      category_id: categoryId,
      name: name.trim(),
      sku: sku.trim(),
      stock: parseInt(stock, 10),
      price: parseFloat(price),
    };

    try {
      if (modalMode === 'create') {
        const res = await axiosClient.post('/items', payload);
        const newItem = res.data.data;
        setItems((prev) => [newItem, ...prev]);
        setIsModalOpen(false);
        trackFormSubmit('item_create', 'success', { name: newItem.name, sku: newItem.sku });
        toast.success(`Barang "${newItem.name}" (SKU: ${newItem.sku}) berhasil ditambahkan!`, 'Barang Ditambahkan');
      } else {
        const res = await axiosClient.put(`/items/${currentItem.id}`, payload);
        const updated = res.data.data;
        setItems((prev) => prev.map((it) => (it.id === updated.id ? updated : it)));
        setIsModalOpen(false);
        trackFormSubmit('item_update', 'success', { id: currentItem.id, name: updated.name });
        toast.success(`Barang "${updated.name}" berhasil diperbarui!`, 'Barang Diperbarui');
      }
    } catch (error) {
      console.error('Error saving item:', error);
      if (error.response?.data?.errors) {
        setFormErrors(error.response.data.errors);
        const firstErr = Object.values(error.response.data.errors)[0]?.[0] || 'Validasi gagal.';
        toast.error(firstErr, 'Validasi Server');
      } else {
        const msg = error.response?.data?.message || 'Gagal menyimpan barang.';
        toast.error(msg, 'Gagal Menyimpan');
      }
      trackFormSubmit('item_form', 'error');
    } finally {
      setFormLoading(false);
    }
  };

  // Delete Action
  const handleOpenDelete = (item) => {
    setItemToDelete(item);
    setDeleteModalOpen(true);
    trackClickCTA('open_delete_item_modal');
  };

  const handleConfirmDelete = async () => {
    if (!itemToDelete) return;
    setDeleteLoading(true);

    try {
      const itemName = itemToDelete.name;
      await axiosClient.delete(`/items/${itemToDelete.id}`);
      setItems((prev) => prev.filter((it) => it.id !== itemToDelete.id));
      setDeleteModalOpen(false);
      setItemToDelete(null);

      toast.success(`Barang "${itemName}" berhasil dihapus dari sistem.`, 'Barang Dihapus');
      trackFormSubmit('item_delete', 'success', { name: itemName });
    } catch (error) {
      console.error('Delete item error:', error);
      const msg = error.response?.data?.message || 'Gagal menghapus barang.';
      toast.error(msg, 'Gagal Menghapus');
      trackFormSubmit('item_delete', 'error', { error: msg });
    } finally {
      setDeleteLoading(false);
    }
  };

  // Export CSV Data Backup
  const handleExportCSV = () => {
    trackClickCTA('export_items_csv');
    if (items.length === 0) {
      toast.warning('Tidak ada data barang untuk di-export.', 'Data Kosong');
      return;
    }

    const headers = ['ID', 'Nama Barang', 'SKU', 'Kategori', 'Stok', 'Harga'];
    const rows = items.map((it) => [
      it.id,
      `"${it.name.replace(/"/g, '""')}"`,
      `"${it.sku}"`,
      `"${it.category?.name || ''}"`,
      it.stock,
      it.price,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `inventaris_barang_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    toast.success(`Berhasil mengexport ${items.length} barang ke file CSV!`, 'Backup CSV');
  };

  // Filtering & Sorting
  const filteredItems = items
    .filter((it) => {
      const matchSearch =
        it.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        it.sku.toLowerCase().includes(searchQuery.toLowerCase());
      return matchSearch;
    })
    .sort((a, b) => {
      if (sortBy === 'name_asc') return a.name.localeCompare(b.name);
      if (sortBy === 'name_desc') return b.name.localeCompare(a.name);
      if (sortBy === 'stock_asc') return a.stock - b.stock;
      if (sortBy === 'stock_desc') return b.stock - a.stock;
      if (sortBy === 'price_asc') return a.price - b.price;
      if (sortBy === 'price_desc') return b.price - a.price;
      return 0;
    });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Breadcrumb Navigation */}
      <Breadcrumbs />

      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-indigo-50 text-indigo-600">
              <Package size={20} />
            </div>
            <h1 className="text-xl font-extrabold text-slate-900 tracking-tight">
              Manajemen Data Barang (Inventaris)
            </h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Pantau stok fisik, kode SKU, penetapan harga produk, dan sinkronisasi kategori.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={() => fetchData(true)}
            className="p-2.5 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 transition"
            title="Refresh data"
          >
            <RefreshCw size={16} />
          </button>

          <button
            type="button"
            onClick={handleExportCSV}
            id="btn-export-csv"
            className="inline-flex items-center gap-2 px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold shadow-xs transition"
          >
            <Download size={15} className="text-slate-500" />
            <span>Export CSV</span>
          </button>

          <button
            type="button"
            onClick={handleOpenCreate}
            id="btn-add-item"
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-md shadow-indigo-200 transition cursor-pointer"
          >
            <Plus size={16} />
            <span>Tambah Barang</span>
          </button>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        {/* Search */}
        <div className="relative flex-1">
          <Search size={16} className="absolute inset-y-0 left-3 my-auto text-slate-400" />
          <input
            type="text"
            placeholder="Cari berdasarkan nama barang atau kode SKU..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Category Filter */}
          <div className="flex items-center gap-1.5 bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-200">
            <Filter size={14} className="text-slate-400" />
            <select
              value={selectedCategory}
              onChange={handleCategoryChange}
              id="filter-category"
              className="bg-transparent text-xs text-slate-700 focus:outline-none cursor-pointer"
            >
              <option value="">Semua Kategori</option>
              {categories.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          {/* Sort By */}
          <div className="flex items-center gap-1.5 bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-200">
            <ArrowUpDown size={14} className="text-slate-400" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="bg-transparent text-xs text-slate-700 focus:outline-none cursor-pointer"
            >
              <option value="name_asc">Nama (A - Z)</option>
              <option value="name_desc">Nama (Z - A)</option>
              <option value="stock_asc">Stok Terendah</option>
              <option value="stock_desc">Stok Tertinggi</option>
              <option value="price_asc">Harga Termurah</option>
              <option value="price_desc">Harga Termahal</option>
            </select>
          </div>
        </div>
      </div>

      {/* Items Table */}
      <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider font-semibold border-b border-slate-100">
              <tr>
                <th className="py-4 px-6">Barang & SKU</th>
                <th className="py-4 px-6">Kategori</th>
                <th className="py-4 px-6">Stok Fisik</th>
                <th className="py-4 px-6">Harga Satuan</th>
                <th className="py-4 px-6">Total Nilai</th>
                <th className="py-4 px-6 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {loading ? (
                <tr>
                  <td colSpan={6} className="text-center py-12 text-slate-400">
                    Memuat data barang dari API...
                  </td>
                </tr>
              ) : filteredItems.length === 0 ? (
                <tr>
                  <td colSpan={6} className="text-center py-12 text-slate-400">
                    <FolderOpen size={36} className="mx-auto text-slate-300 mb-2" />
                    <p className="font-semibold text-slate-600">Tidak ada barang ditemukan</p>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      {searchQuery || selectedCategory
                        ? 'Coba sesuaikan pencarian atau reset filter kategori.'
                        : 'Klik tombol "Tambah Barang" untuk mulai mencatat barang inventaris.'}
                    </p>
                  </td>
                </tr>
              ) : (
                filteredItems.map((item) => {
                  const itemVal = Number(item.stock) * Number(item.price);
                  return (
                    <tr key={item.id} className="hover:bg-slate-50/80 transition">
                      <td className="py-4 px-6">
                        <div className="font-bold text-slate-900">{item.name}</div>
                        <div className="font-mono text-[11px] text-indigo-600 mt-0.5">SKU: {item.sku}</div>
                      </td>
                      <td className="py-4 px-6">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-slate-100 text-slate-700">
                          {item.category?.name || '-'}
                        </span>
                      </td>
                      <td className="py-4 px-6">
                        <div className="font-semibold text-slate-800">{item.stock} unit</div>
                        {Number(item.stock) <= 5 ? (
                          <span className="inline-block mt-0.5 text-[10px] font-bold text-rose-600">
                            Stok Kritis
                          </span>
                        ) : Number(item.stock) < 10 ? (
                          <span className="inline-block mt-0.5 text-[10px] font-bold text-amber-600">
                            Menipis
                          </span>
                        ) : null}
                      </td>
                      <td className="py-4 px-6 font-medium text-slate-800">{formatIDR(item.price)}</td>
                      <td className="py-4 px-6 font-semibold text-slate-900">{formatIDR(itemVal)}</td>
                      <td className="py-4 px-6 text-right">
                        <div className="inline-flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => handleOpenEdit(item)}
                            className="p-1.5 text-indigo-600 hover:bg-indigo-50 rounded-lg transition"
                            title="Edit barang"
                          >
                            <Edit2 size={15} />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleOpenDelete(item)}
                            className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg transition"
                            title="Hapus barang"
                          >
                            <Trash2 size={15} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create / Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-fade-in">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-100 relative max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-indigo-50 text-indigo-600">
                  <Package size={18} />
                </div>
                <h3 className="text-sm font-bold text-slate-900">
                  {modalMode === 'create' ? 'Tambah Barang Baru' : 'Edit Data Barang'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSubmitItem} className="mt-4 space-y-4" noValidate>
              {/* Anti-spam honeypot */}
              <div style={{ display: 'none' }} aria-hidden="true">
                <input
                  type="text"
                  name="_hp_item"
                  value={honeypot}
                  onChange={(e) => setHoneypot(e.target.value)}
                />
              </div>

              {/* Kategori */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5" htmlFor="item-cat">
                  Kategori <span className="text-rose-500">*</span>
                </label>
                <select
                  id="item-cat"
                  required
                  value={categoryId}
                  onChange={(e) => setCategoryId(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="" disabled>
                    -- Pilih Kategori --
                  </option>
                  {categories.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
                {formErrors.category_id && (
                  <p className="text-[11px] text-rose-600 mt-1">{formErrors.category_id[0]}</p>
                )}
              </div>

              {/* Nama Barang */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5" htmlFor="item-name">
                  Nama Barang <span className="text-rose-500">*</span>
                </label>
                <input
                  id="item-name"
                  type="text"
                  required
                  placeholder="Misal: Monitor LG 24 Inch"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
                {formErrors.name && <p className="text-[11px] text-rose-600 mt-1">{formErrors.name[0]}</p>}
              </div>

              {/* SKU with Generator */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-semibold text-slate-700" htmlFor="item-sku">
                    Kode SKU (Stock Keeping Unit) <span className="text-rose-500">*</span>
                  </label>
                  <button
                    type="button"
                    onClick={generateSkuHelper}
                    className="text-[10px] text-indigo-600 hover:text-indigo-700 font-semibold flex items-center gap-1"
                  >
                    <Sparkles size={11} />
                    <span>Generate SKU Otomatis</span>
                  </button>
                </div>
                <input
                  id="item-sku"
                  type="text"
                  required
                  placeholder="Misal: ELK-MNT-001"
                  value={sku}
                  onChange={(e) => setSku(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
                {formErrors.sku && <p className="text-[11px] text-rose-600 mt-1">{formErrors.sku[0]}</p>}
              </div>

              {/* Stok & Harga Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5" htmlFor="item-stock">
                    Jumlah Stok <span className="text-rose-500">*</span>
                  </label>
                  <input
                    id="item-stock"
                    type="number"
                    min="0"
                    required
                    placeholder="0"
                    value={stock}
                    onChange={(e) => setStock(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                  {formErrors.stock && <p className="text-[11px] text-rose-600 mt-1">{formErrors.stock[0]}</p>}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5" htmlFor="item-price">
                    Harga Satuan (IDR) <span className="text-rose-500">*</span>
                  </label>
                  <input
                    id="item-price"
                    type="number"
                    min="0"
                    step="1000"
                    required
                    placeholder="100000"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                  {formErrors.price && <p className="text-[11px] text-rose-600 mt-1">{formErrors.price[0]}</p>}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={formLoading}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 shadow-md shadow-indigo-200 transition disabled:opacity-50"
                >
                  {formLoading ? 'Menyimpan...' : modalMode === 'create' ? 'Tambah Barang' : 'Simpan Perubahan'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Item Confirmation Modal */}
      {deleteModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-fade-in">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl border border-slate-100 text-center">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto mb-3">
              <AlertTriangle size={24} />
            </div>
            <h3 className="text-sm font-bold text-slate-900">Konfirmasi Hapus Barang</h3>
            <p className="text-xs text-slate-500 mt-2 leading-relaxed">
              Apakah Anda yakin ingin menghapus barang <strong className="text-slate-800">"{itemToDelete?.name}"</strong> (SKU: {itemToDelete?.sku})?
            </p>

            <div className="flex items-center justify-center gap-2 mt-5">
              <button
                type="button"
                onClick={() => setDeleteModalOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition"
              >
                Batal
              </button>
              <button
                type="button"
                disabled={deleteLoading}
                onClick={handleConfirmDelete}
                className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 shadow-md shadow-rose-200 transition disabled:opacity-50"
              >
                {deleteLoading ? 'Menghapus...' : 'Ya, Hapus Barang'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Items;
